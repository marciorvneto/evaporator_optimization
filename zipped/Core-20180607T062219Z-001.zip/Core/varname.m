function name = varname( ~ )
    name = inputname(1);
end

