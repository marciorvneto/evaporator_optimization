function y=closeTo(x,y,tol)

    y = abs(x-y)<tol;

end