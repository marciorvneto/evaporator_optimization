function y = BPR(x,T,P)
%BPR calculations

y = 6.173*x - 7.48*x*x^(0.5) + 32.747*x^2;


end

